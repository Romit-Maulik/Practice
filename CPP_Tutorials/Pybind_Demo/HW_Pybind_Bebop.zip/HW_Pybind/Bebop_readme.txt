# To run this app on Bebop
1. Unload all modules (except StdEnv) using module unload

2. Load the following modules (this reproduces the OF build environment)
% module list
1) StdEnv              3) metis/5.1.0-pfih7wr     5) qt/5.6.3-gcc-4.8.5     7) tensorflow/2.0.0
2) gcc/7.1.0-4bgguyp   4) openmpi/3.1.3-edz4siy   6) cmake/3.14.4-kmpms6b

3. You can build using `./clean_make.sh` and test using `./test.sh`